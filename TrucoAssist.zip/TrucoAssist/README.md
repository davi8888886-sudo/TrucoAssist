# Truco Assist (MVP Android / Kotlin)

Assistente que **apenas sugere jogadas** (carta a jogar + conselho de truco). **Não** toca na tela, **não** automatiza
jogadas e **não** tenta burlar anti-cheat, `FLAG_SECURE` ou regras de qualquer jogo. Use somente em jogos próprios,
testes ou partidas em que ferramentas externas sejam permitidas. Se um app bloquear captura, o quadro vem preto e
o app não faz nada para contornar isso.

## Como rodar
Abra a pasta no Android Studio (Ladybug+), deixe o Gradle sincronizar (o wrapper baixa o Gradle 8.9) e rode em um
dispositivo Android 8.0+ (minSdk 26, targetSdk 35). Testes: `./gradlew test` (motor de regras).

## Fluxo
1. Escolha a variante (Paulista/Mineiro) e, se quiser, ative o painel flutuante e conceda a sobreposição.
2. **Iniciar captura** → Android mostra o diálogo de consentimento do MediaProjection (no Android 14+ dá para
   limitar a um único app). Aparece a notificação persistente com botão **Parar**.
3. No painel flutuante, **Analisar** lê o último quadro, faz OCR e mostra a sugestão. Arraste pelo cabeçalho; "—" recolhe.

## Escolhas de projeto (todas ajustáveis na tela principal)
- **Foreground service** `mediaProjection`: `startForeground` antes de `getMediaProjection`, callback registrado antes
  do `VirtualDisplay`, um único `VirtualDisplay` redimensionado na rotação (regras do Android 14+).
- **Captura sob demanda**: só mantém o último quadro; o OCR roda apenas ao tocar em Analisar (economiza bateria).
- **OCR**: ML Kit offline em regiões da tela (% esq,topo,dir,base) para mão, vira e mesa; padrões em `Prefs.kt`.
  Lê o *valor* das cartas; o **naipe é só estimado pela cor** (vermelho→copas, preto→paus). Isso é impreciso:
  afeta o desempate das manilhas no Paulista e as manilhas fixas do Mineiro. Quando o OCR não acha cartas, usa a
  **entrada manual** (ex.: `3P 2C AE`), que também funciona sozinha pelo botão "Sugerir jogada (manual)".
- **Variantes**: Paulista (manilha = carta seguinte à vira, naipes ♦<♠<♥<♣) e Mineiro (7♦ < A♠ < 7♥ < 4♣ fixas).
  Baralho de 40 cartas. Pontos da rodada/rodadas ganhas e perdidas são informados manualmente.
- **Heurística** (`TrucoEngine`): carta mais barata que vence a da mesa; abre com a carta do meio na 1ª rodada;
  fecha com a mais forte após vencer; força da mão (manilha 4–7, 3=3, 2=2, A=1) vs. **limiar de truco** (padrão 8).

## Limitações / próximos passos
Sem placar nem blefe/leitura de histórico, sem detecção de naipe por template, sem calibração visual das regiões,
sem suporte a Truco com 4 jogadores/parceiro, sem ícone próprio. O build não foi executado no ambiente que gerou o projeto.
