package com.example.trucoassist.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import com.example.trucoassist.Prefs
import com.example.trucoassist.engine.Card
import com.example.trucoassist.engine.Rank
import com.example.trucoassist.engine.Suit
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

object RoiParser {
    /** "esq,topo,dir,base" em % -> Rect em pixels. */
    fun parse(s: String, w: Int, h: Int): Rect? {
        val p = s.split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (p.size != 4) return null
        val l = (p[0] / 100f * w).toInt().coerceIn(0, w - 1)
        val t = (p[1] / 100f * h).toInt().coerceIn(0, h - 1)
        val r = (p[2] / 100f * w).toInt().coerceIn(1, w)
        val b = (p[3] / 100f * h).toInt().coerceIn(1, h)
        return if (r > l && b > t) Rect(l, t, r, b) else null
    }
}

/**
 * Lê o VALOR das cartas por OCR nas regiões configuradas. O naipe é apenas estimado pela cor
 * (vermelho -> copas, preto -> paus), então é aproximado. Para o Mineiro (manilhas fixas) use a entrada manual.
 */
class OcrCardRecognizer {
    data class Result(val hand: List<Card>, val vira: Card?, val table: Card?)

    private val client = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /** Recorta as regiões de forma síncrona (o chamador pode reciclar [src] depois). */
    fun recognize(src: Bitmap, prefs: Prefs, onDone: (Result) -> Unit, onError: (Exception) -> Unit) {
        val hand = crop(src, prefs.roiHand)
        val vira = crop(src, prefs.roiVira)
        val table = crop(src, prefs.roiTable)
        read(hand, onError) { h ->
            read(vira, onError) { v ->
                read(table, onError) { t -> onDone(Result(h, v.firstOrNull(), t.firstOrNull())) }
            }
        }
    }

    private fun crop(src: Bitmap, roi: String): Bitmap? {
        val r = RoiParser.parse(roi, src.width, src.height) ?: return null
        return Bitmap.createBitmap(src, r.left, r.top, r.width(), r.height())
    }

    private fun read(bmp: Bitmap?, onError: (Exception) -> Unit, ok: (List<Card>) -> Unit) {
        if (bmp == null) { ok(emptyList()); return }
        client.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                val cards = text.textBlocks.flatMap { it.lines }.flatMap { it.elements }
                    .mapNotNull { el ->
                        val box = el.boundingBox ?: return@mapNotNull null
                        val label = el.text.trim()
                        if (label.length != 1) return@mapNotNull null
                        val rank = Rank.fromLabel(label) ?: return@mapNotNull null
                        Triple(box, rank, isRed(bmp, box))
                    }
                    .sortedBy { it.first.left }
                    .map { (_, rank, red) -> Card(rank, if (red) Suit.COPAS else Suit.PAUS) }
                bmp.recycle()
                ok(cards)
            }
            .addOnFailureListener { bmp.recycle(); onError(it) }
    }

    private fun isRed(b: Bitmap, box: Rect): Boolean {
        val x0 = box.left.coerceAtLeast(0); val x1 = box.right.coerceAtMost(b.width)
        val y0 = box.top.coerceAtLeast(0); val y1 = box.bottom.coerceAtMost(b.height)
        var red = 0; var n = 0
        for (y in y0 until y1 step 2) for (x in x0 until x1 step 2) {
            val c = b.getPixel(x, y)
            if (Color.red(c) > 150 && Color.green(c) < 110 && Color.blue(c) < 110) red++
            n++
        }
        return n > 0 && red * 100 / n >= 4
    }
}
