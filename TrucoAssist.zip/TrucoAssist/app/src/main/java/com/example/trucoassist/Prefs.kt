package com.example.trucoassist

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Todas as configurações ajustáveis ficam aqui (SharedPreferences). */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("truco_assist", Context.MODE_PRIVATE)

    var variant by str("variant", "PAULISTA")          // PAULISTA | MINEIRO
    var roiHand by str("roiHand", "5,70,95,98")        // % da tela: esq,topo,dir,base
    var roiVira by str("roiVira", "40,35,60,55")
    var roiTable by str("roiTable", "30,45,70,68")
    var manualHand by str("manualHand", "")
    var manualVira by str("manualVira", "")
    var manualTable by str("manualTable", "")
    var trucoThreshold by int("threshold", 8)
    var round by int("round", 1)
    var roundsWon by int("won", 0)
    var roundsLost by int("lost", 0)
    var overlayEnabled by bool("overlay", false)

    private fun str(k: String, d: String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) =
            sp.edit().putString(k, value).apply()
    }
    private fun int(k: String, d: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) =
            sp.edit().putInt(k, value).apply()
    }
    private fun bool(k: String, d: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) =
            sp.edit().putBoolean(k, value).apply()
    }
}
