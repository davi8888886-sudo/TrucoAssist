package com.example.trucoassist.engine

/** Ordem crescente de força para desempate de manilhas no Paulista: ouros < espadas < copas < paus. */
enum class Suit(val symbol: String, val code: Char) {
    OUROS("♦", 'O'), ESPADAS("♠", 'E'), COPAS("♥", 'C'), PAUS("♣", 'P')
}

/** Baralho de 40 cartas. Ordem crescente de força (sem manilhas): 4 5 6 7 Q J K A 2 3. */
enum class Rank(val label: String) {
    QUATRO("4"), CINCO("5"), SEIS("6"), SETE("7"), DAMA("Q"),
    VALETE("J"), REI("K"), AS("A"), DOIS("2"), TRES("3");

    companion object {
        fun fromLabel(s: String): Rank? = entries.firstOrNull { it.label.equals(s, ignoreCase = true) }
    }
}

data class Card(val rank: Rank, val suit: Suit) {
    override fun toString() = rank.label + suit.symbol
}

data class GameState(
    val hand: List<Card>,
    val vira: Card? = null,
    /** Carta já jogada pelo adversário na rodada atual (se ele jogou antes de você). */
    val table: Card? = null,
    val roundNumber: Int = 1,
    val roundsWon: Int = 0,
    val roundsLost: Int = 0,
)

data class Suggestion(val card: Card?, val trucoAdvice: String?, val explanation: String)

/** Lê "3P 2C AE" -> cartas. Valor (4-7,Q,J,K,A,2,3) + naipe (O,E,C,P). */
object CardParser {
    private val re = Regex("""([2-7AJQKajqk])([OECPoecp])""")
    fun parse(text: String): List<Card> = re.findAll(text).mapNotNull { m ->
        val rank = Rank.fromLabel(m.groupValues[1])
        val suit = Suit.entries.firstOrNull { it.code == m.groupValues[2].uppercase()[0] }
        if (rank != null && suit != null) Card(rank, suit) else null
    }.toList()
}
