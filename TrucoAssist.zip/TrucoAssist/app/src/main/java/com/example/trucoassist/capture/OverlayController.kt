package com.example.trucoassist.capture

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import com.example.trucoassist.R

/** Painel flutuante opcional (TYPE_APPLICATION_OVERLAY). Só mostra texto e dispara "Analisar". */
class OverlayController(private val ctx: Context, private val onAnalyze: () -> Unit) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var view: View? = null
    private lateinit var params: WindowManager.LayoutParams

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (view != null || !Settings.canDrawOverlays(ctx)) return
        val v = LayoutInflater.from(ContextThemeWrapper(ctx, R.style.Theme_TrucoAssist))
            .inflate(R.layout.overlay_panel, null)
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 200 }

        v.findViewById<Button>(R.id.btnAnalyze).setOnClickListener { onAnalyze() }
        val text = v.findViewById<TextView>(R.id.tvSuggestion)
        val collapse = v.findViewById<Button>(R.id.btnCollapse)
        collapse.setOnClickListener {
            val hide = text.visibility == View.VISIBLE
            text.visibility = if (hide) View.GONE else View.VISIBLE
            collapse.text = if (hide) "+" else "—"
        }
        v.findViewById<View>(R.id.tvHandle).setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(h: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = sx + (e.rawX - tx).toInt(); params.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(view, params)
                    }
                }
                return true
            }
        })
        wm.addView(v, params)
        view = v
    }

    fun setText(t: String) = main.post { view?.findViewById<TextView>(R.id.tvSuggestion)?.text = t }

    fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}
