package com.example.trucoassist.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.trucoassist.MainActivity
import com.example.trucoassist.Prefs
import com.example.trucoassist.engine.CardParser
import com.example.trucoassist.engine.GameState
import com.example.trucoassist.engine.TrucoEngine
import com.example.trucoassist.engine.Variants
import com.example.trucoassist.engine.formatReport
import com.example.trucoassist.vision.OcrCardRecognizer
import java.util.concurrent.Executors

/**
 * Foreground service (tipo mediaProjection). Mantém o último quadro da tela em memória e só o
 * analisa quando o usuário toca em "Analisar". Nunca injeta toques nem automatiza jogadas.
 */
class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.trucoassist.START"
        const val ACTION_STOP = "com.example.trucoassist.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "capture"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }

    private data class Dim(val w: Int, val h: Int, val dpi: Int)

    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var prefs: Prefs
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestImage: Image? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var overlay: OverlayController? = null
    private var recognizer: OcrCardRecognizer? = null

    override fun onCreate() { super.onCreate(); prefs = Prefs(this) }
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        try {
            // Android 14+: startForeground (tipo mediaProjection) ANTES de getMediaProjection.
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else startForeground(NOTIF_ID, n)
            if (running) return

            val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
            val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
            if (code != Activity.RESULT_OK || data == null) { stopSelf(); return }

            thread = HandlerThread("truco-capture").also { it.start() }
            handler = Handler(thread!!.looper)
            val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            projection = p
            // Obrigatório no Android 14+: registrar callback antes de criar o VirtualDisplay.
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, handler)

            val d = dims()
            val reader = newReader(d)
            virtualDisplay = p.createVirtualDisplay(
                "truco-capture", d.w, d.h, d.dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, handler,
            )
            recognizer = OcrCardRecognizer()
            running = true
            if (prefs.overlayEnabled) overlay = OverlayController(this) { analyze() }.also { it.show() }
        } catch (e: Exception) {
            Toast.makeText(this, "Falha ao iniciar captura: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun dims(): Dim {
        val dpi = resources.configuration.densityDpi
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
            Dim(b.width(), b.height(), dpi)
        } else {
            val m = resources.displayMetrics
            Dim(m.widthPixels, m.heightPixels, dpi)
        }
    }

    private fun newReader(d: Dim): ImageReader =
        ImageReader.newInstance(d.w, d.h, PixelFormat.RGBA_8888, 3).also { r ->
            imageReader = r
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (_: Exception) { null }
                if (img != null) synchronized(lock) { latestImage?.close(); latestImage = img }
            }, handler)
        }

    /** Rotação: redimensiona o mesmo VirtualDisplay (só pode ser criado uma vez por projeção). */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val vd = virtualDisplay ?: return
        val d = dims()
        synchronized(lock) { latestImage?.close(); latestImage = null }
        imageReader?.close()
        val r = newReader(d)
        vd.resize(d.w, d.h, d.dpi)
        vd.surface = r.surface
    }

    private fun snapshot(): Bitmap? = synchronized(lock) {
        val img = latestImage ?: return null
        val plane = img.planes[0]
        val rowPixels = plane.rowStride / plane.pixelStride
        val padded = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        if (rowPixels == img.width) padded
        else Bitmap.createBitmap(padded, 0, 0, img.width, img.height).also { padded.recycle() }
    }

    private fun analyze() {
        overlay?.setText("Analisando…")
        executor.execute {
            val bmp = try { snapshot() } catch (_: Exception) { null }
            val rec = recognizer
            if (bmp == null || rec == null) { main.post { present(null) }; return@execute }
            try {
                rec.recognize(bmp, prefs,
                    { res -> main.post { present(res) } },
                    { e -> main.post { overlay?.setText("Erro de OCR: ${e.message}") } })
            } finally { bmp.recycle() }
        }
    }

    private fun present(res: OcrCardRecognizer.Result?) {
        val usedOcr = res != null && res.hand.isNotEmpty()
        val hand = if (usedOcr) res!!.hand else CardParser.parse(prefs.manualHand)
        val vira = if (usedOcr) res!!.vira else CardParser.parse(prefs.manualVira).firstOrNull()
        val table = if (usedOcr) res!!.table else CardParser.parse(prefs.manualTable).firstOrNull()
        if (hand.isEmpty()) {
            overlay?.setText("Não encontrei cartas. Ajuste as regiões do OCR ou use a entrada manual no app.")
            return
        }
        val engine = TrucoEngine(Variants.byName(prefs.variant), prefs.trucoThreshold)
        val s = engine.suggest(GameState(hand, vira, table, prefs.round, prefs.roundsWon, prefs.roundsLost))
        val note = if (usedOcr) "(valores por OCR; naipes estimados pela cor)" else "(OCR vazio: usei a entrada manual)"
        overlay?.setText(formatReport(hand, vira, table, s, note))
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Captura de tela", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Truco Assist: captura ativa")
            .setContentText("Só sugere jogadas. Toque para abrir ou use Parar.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Parar", stop)
            .build()
    }

    override fun onDestroy() {
        running = false
        overlay?.hide()
        virtualDisplay?.release()
        imageReader?.close()
        synchronized(lock) { latestImage?.close(); latestImage = null }
        projection?.stop()
        thread?.quitSafely()
        executor.shutdownNow()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
